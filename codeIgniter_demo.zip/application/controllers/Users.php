<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	
	public function add()
	{
		$page_name = 'add_user';
		$data['page_name'] = $page_name;
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->view('header',$data);
		if ($this->input->post()) {
			 /* Load form validation library */ 
			 $this->load->library('form_validation');
			 /* Set validation rule for name field in the form */ 
			 $this->form_validation->set_rules('first_name', 'First Name', 'required'); 
			 $this->form_validation->set_rules('last_name', 'Last Name', 'required'); 
			 $this->form_validation->set_rules('dob', 'Date of birth', 'required'); 
			 $this->form_validation->set_rules('address', 'Address', 'required'); 
			 
			 if ($this->form_validation->run() == FALSE) {
				$this->load->view('add');
			 }else{
				$post_data = $this->input->post ();
				
				
				
				
				$insert_data['first_name']=$post_data['first_name'];
				$insert_data['last_name']=$post_data['last_name'];
				$insert_data['dob']=$post_data['dob'];
				$insert_data['address']=$post_data['address'];
				$this->load->model('User_model');
				$user=$this->User_model->insert_entry($insert_data);
				if($user>0){
					$work_experience_data = array();
					$portfolio_image_data = array();
					if(!empty($post_data['work_experience'])){
						foreach($post_data['work_experience'] as $key=>$value){
					
							$work_experience_data[] = array(
							'user_id'  => $user,
							'company_name'  => $value['company_name'], 
							'company_description'=>  $value['company_description'],
							);
						}
					}
					if(!empty($work_experience_data)){
						$this->db->insert_batch('users_work_experience', $work_experience_data);  
					}
					if(!empty($post_data['image_name'])){
						foreach($post_data['image_name'] as $value){
					
							$portfolio_image_data[] = array(
							'user_id'  => $user,
							'portfolio_image_name'=> $value,
							);
						}
					}
					if(!empty($portfolio_image_data)){
						$this->db->insert_batch('user_portfolio_images', $portfolio_image_data);  
					}
					 redirect('/users/users_listings');
				}
				else{
					echo "Insert error !";die;
				} 
			}	
		}else{
			$this->load->view('add');
		}
		$this->load->view('footer');
	}
	
	public function users_listings(){
		$page_name = 'users_listings';
		$data['page_name'] = $page_name;
		$this->load->helper('url');
		$this->load->view('header',$data);
		$this->load->model('User_model');
		$result['data'] =$this->User_model->users_listings();
		$this->load->view('users_listings',$result);
		$this->load->view('footer');
	}
	
	public function user_experience_listings($id){
		$page_name = 'user_experience_listings';
		$data['page_name'] = $page_name;
		$this->load->helper('url');
		$this->load->view('header',$data);
		$this->load->model('User_model');
		
		$user_detail = $this->db // get the user detail
		->select('id,first_name,last_name')
		->from('users')
		->where('id', $id)
		->get()->row_array();
		
		$result['user_detail'] = $user_detail;
		$result['data'] =$this->User_model->user_experience_listings($id);
		$this->load->view('user_experience_listings',$result);
		$this->load->view('footer');
	}
	
	public function user_portfolio_images_listings($id){
		$page_name = 'user_portfolio_images_listings';
		$data['page_name'] = $page_name;
		$this->load->helper('url');
		$this->load->view('header',$data);
		$this->load->model('User_model');
		
		$user_detail = $this->db // get the user detail
		->select('id,first_name,last_name')
		->from('users')
		->where('id', $id)
		->get()->row_array();
		
		$result['user_detail'] = $user_detail;
		$result['data'] =$this->User_model->user_portfolio_images_listings($id);

		$this->load->view('user_portfolio_images_listings',$result);
		$this->load->view('footer');
	}
	
	
	public function upload_portfolio_image()
	{
		if($this->input->is_ajax_request ()){
			if(!empty($_FILES)){ 
				// File upload configuration 
				$uploadPath = 'uploads/'; 
				$config['upload_path'] = $uploadPath; 
				$config['allowed_types'] = '*'; 
				// Load and initialize upload library 
				$this->load->library('upload', $config); 
				$this->upload->initialize($config); 
				 
				// Upload file to the server 
				if($this->upload->do_upload('file')){ 
					$fileData = $this->upload->data();
					$insert_id = $this->db->insert_id();
					echo json_encode(['status' => 200,'insert_id'=>$insert_id]);
					die;
				} 
			} 
		}else{
			echo json_encode(['status' => 400]);
			die;
		}
	
	}
	
	public function delete_portfolio_image()
	{
		if($this->input->is_ajax_request ()){
			$post_data = $this->input->post ();
			$image_name = $post_data['name'];
			$this->db->delete('user_portfolio_images', array('portfolio_image_name' => $image_name));
			$uploadPath = 'uploads/'; 
			unlink($uploadPath.$image_name);
			echo json_encode(['status' => 200,'name'=>$image_name]);
		}else{
			echo json_encode(['status' => 400]);
			die;
		}
	}
}
