<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-16 11:38:17 --> Severity: Error --> Call to undefined function form_open() F:\xampp\htdocs\codeIgniter_demo\application\views\add.php 6
ERROR - 2021-01-16 11:51:29 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 29
ERROR - 2021-01-16 11:51:45 --> Severity: Notice --> Undefined property: Users::$User_model F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 26
ERROR - 2021-01-16 11:51:45 --> Severity: Error --> Call to a member function saverecords() on null F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 26
ERROR - 2021-01-16 11:53:53 --> Severity: error --> Exception: Unable to locate the model you have specified: User F:\xampp\htdocs\codeIgniter_demo\system\core\Loader.php 348
ERROR - 2021-01-16 11:58:42 --> Severity: Notice --> Undefined property: Users::$db F:\xampp\htdocs\codeIgniter_demo\system\core\Model.php 73
ERROR - 2021-01-16 11:58:42 --> Severity: Error --> Call to a member function insert() on null F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 10
ERROR - 2021-01-16 12:02:11 --> Severity: Notice --> Undefined property: Users::$db F:\xampp\htdocs\codeIgniter_demo\system\core\Model.php 73
ERROR - 2021-01-16 12:02:11 --> Severity: Error --> Call to a member function insert() on null F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 10
ERROR - 2021-01-16 12:02:44 --> Severity: Notice --> Undefined property: Users::$db F:\xampp\htdocs\codeIgniter_demo\system\core\Model.php 73
ERROR - 2021-01-16 12:02:44 --> Severity: Error --> Call to a member function insert() on null F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 10
ERROR - 2021-01-16 12:03:15 --> Severity: Notice --> Undefined property: Users::$user_model F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 11
ERROR - 2021-01-16 12:03:15 --> Severity: Error --> Call to a member function insert_entry() on null F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 11
ERROR - 2021-01-16 12:03:22 --> Severity: Notice --> Undefined property: Users::$user F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 11
ERROR - 2021-01-16 12:03:22 --> Severity: Error --> Call to a member function insert_entry() on null F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 11
ERROR - 2021-01-16 12:07:38 --> Severity: error --> Exception: Unable to locate the model you have specified: User F:\xampp\htdocs\codeIgniter_demo\system\core\Loader.php 348
ERROR - 2021-01-16 12:08:39 --> Severity: Notice --> Undefined property: Users::$db F:\xampp\htdocs\codeIgniter_demo\system\core\Model.php 73
ERROR - 2021-01-16 12:08:39 --> Severity: Error --> Call to a member function insert() on null F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 10
ERROR - 2021-01-16 12:09:47 --> Severity: Notice --> Undefined property: Users::$db F:\xampp\htdocs\codeIgniter_demo\system\core\Model.php 73
ERROR - 2021-01-16 12:09:47 --> Severity: Error --> Call to a member function insert() on null F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 11
ERROR - 2021-01-16 12:11:18 --> Severity: Notice --> Undefined property: Users::$db F:\xampp\htdocs\codeIgniter_demo\system\core\Model.php 73
ERROR - 2021-01-16 12:11:18 --> Severity: Error --> Call to a member function insert() on null F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 13
ERROR - 2021-01-16 12:11:20 --> Severity: Notice --> Undefined property: Users::$db F:\xampp\htdocs\codeIgniter_demo\system\core\Model.php 73
ERROR - 2021-01-16 12:11:20 --> Severity: Error --> Call to a member function insert() on null F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 13
ERROR - 2021-01-16 12:13:40 --> Severity: error --> Exception: Unable to locate the model you have specified: User F:\xampp\htdocs\codeIgniter_demo\system\core\Loader.php 348
ERROR - 2021-01-16 12:14:22 --> Severity: error --> Exception: Unable to locate the model you have specified: User F:\xampp\htdocs\codeIgniter_demo\system\core\Loader.php 348
ERROR - 2021-01-16 12:14:38 --> Severity: Notice --> Undefined variable: data F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 10
ERROR - 2021-01-16 12:15:26 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ';' or '{' F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 9
ERROR - 2021-01-16 12:35:22 --> Severity: Notice --> Undefined index: first_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 17
ERROR - 2021-01-16 12:35:22 --> Severity: Notice --> Undefined index: last_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 18
ERROR - 2021-01-16 12:35:22 --> Severity: Notice --> Undefined index: dob F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 19
ERROR - 2021-01-16 12:35:22 --> Severity: Notice --> Undefined index: address F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 20
ERROR - 2021-01-16 13:10:41 --> Severity: Error --> Call to undefined function base_url() F:\xampp\htdocs\codeIgniter_demo\application\views\header.php 12
ERROR - 2021-01-16 13:25:28 --> Severity: Notice --> Undefined variable: data F:\xampp\htdocs\codeIgniter_demo\application\views\users_listings.php 2
ERROR - 2021-01-16 13:39:12 --> 404 Page Not Found: Users/users_listing
ERROR - 2021-01-16 13:41:12 --> 404 Page Not Found: Users/user_experience_listings
ERROR - 2021-01-16 13:45:07 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) F:\xampp\htdocs\codeIgniter_demo\application\models\User_model.php 24
ERROR - 2021-01-16 13:45:17 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `user_id` = '6'
ORDER BY `company_name` ASC
ERROR - 2021-01-16 13:51:02 --> Query error: Unknown column 'u.id' in 'field list' - Invalid query: SELECT `u`.`id`, `u`.`first_name`, `u`.`last_name`
FROM `users`
WHERE `id` = '6'
ERROR - 2021-01-16 14:01:40 --> Query error: Unknown column 'page_name' in 'field list' - Invalid query: INSERT INTO `users` (`page_name`, `first_name`, `last_name`, `dob`, `address`) VALUES ('add_user', 'dsaddsadas', 'dasdsa', '2021-01-28', 'asdsad')
ERROR - 2021-01-16 14:22:11 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 106
ERROR - 2021-01-16 14:22:11 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 108
ERROR - 2021-01-16 14:22:40 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 106
ERROR - 2021-01-16 14:22:40 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 108
ERROR - 2021-01-16 14:25:56 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 106
ERROR - 2021-01-16 14:25:56 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 108
ERROR - 2021-01-16 14:26:18 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 106
ERROR - 2021-01-16 14:26:18 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 108
ERROR - 2021-01-16 14:29:35 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 125
ERROR - 2021-01-16 14:29:40 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 125
ERROR - 2021-01-16 14:30:22 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:30:27 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:36:38 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:36:42 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:41:18 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:41:35 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:42:26 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:43:09 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:43:54 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:45:43 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
ERROR - 2021-01-16 14:46:17 --> Severity: Notice --> Undefined index: portfolio_image_name F:\xampp\htdocs\codeIgniter_demo\application\controllers\Users.php 123
