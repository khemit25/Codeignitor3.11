<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta charset="UTF-8">
        <title>DEMO</title>
	    <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        
		<link rel="stylesheet" type="text/css" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/3.3.7/paper/bootstrap.min.css" />
		
		
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" />
		<?php
		if($page_name == 'add_user'){
		?>
        <link id="bsdp-css" href="<?php echo base_url(); ?>assets/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/dropzone.min.css" />
		<?php
		}
		if($page_name == 'users_listings' || $page_name == 'user_experience_listings' ||  $page_name == 'user_portfolio_images_listings'){
		?>
		<link rel="stylesheet" type="text/css" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.0/css/materialize.min.css" />
		<link rel="stylesheet" type="text/css" media="screen" href="https://fonts.googleapis.com/icon?family=Material+Icons" />	
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/datatable.css" />
		<?php
		}
		?>
		
		<script src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.js"></script>
		<?php
		if($page_name == 'add_user'){
		?>
        <script src="<?php echo base_url(); ?>assets/js/dropzone.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.min.js"></script>
		<?php
		}
		if($page_name == 'users_listings' || $page_name == 'user_experience_listings' ||  $page_name == 'user_portfolio_images_listings'){
		?>
		<script src="https://cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.0/js/materialize.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/datatable.js"></script>
		<?php
		}
		?>
    </head>
<body id="body" >