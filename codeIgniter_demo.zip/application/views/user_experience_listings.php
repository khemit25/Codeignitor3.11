<div class="row">
  <div id="admin" class="col s12">
    <div class="card material-table">
	
      <div class="table-header">
        <span class="table-title">Experiences of <strong><?php echo $user_detail['first_name'].' '.$user_detail['last_name']; ?></strong></span>
        <div class="actions">
          <a href="<?php echo site_url('users/users_listings') ?>" class="modal-trigger waves-effect btn-flat nopadding">Back</a>
          <a href="#" class="search-toggle waves-effect btn-flat nopadding"><i class="material-icons">search</i></a>
        </div>
      </div>
      <table id="datatable">
        <thead>
          <tr>
            <th>Company Name</th>
            <th>Description</th>
          </tr>
        </thead>
        <tbody>
			<?php
			foreach($data as $result){
			?>
          <tr>
            <td><?php echo $result->company_name; ?></td>           
            <td><?php echo $result->company_description; ?></td> 
          </tr>
		  <?php
		  }
		  ?>
        </tbody>
		
      </table>
    </div>
  </div>
</div>