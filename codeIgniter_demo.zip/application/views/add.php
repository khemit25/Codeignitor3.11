 <div class="main">
        <section class="signup">
            <div class="container">
                <div class="signup-content">
					<?php echo validation_errors(); ?>  
                    <?php echo form_open('users/add',['id'=>'add']); ?>
                        <h2 class="form-title">Create account </h2>
                        <div class="form-group">
                            <input type="text" class="form-input" name="first_name" id="first_name" placeholder="First Name" required/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-input" name="last_name" id="last_name" placeholder="Last Name" required/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-input datepicker"  name="dob" id="dob" placeholder="Birth of Date" required/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-input" name="address" id="address" placeholder="Address" required/>
                        </div>
						<h2 class="form-title">Experiences</h2>
						<div>							
							<div class="items" data-group="test">
								<div id="field">
								<div id="field0">
								<!-- Repeater Content -->
								<div class="item-content">
									<div class="form-group">
										<div class="col-lg-10">
											<input type="text" class="form-input" id="company_name" placeholder="Company Name" data-name="company_name" name="work_experience[0][company_name]" required>
										</div>
									</div>
									<div class="form-group">
										<div class="col-lg-10">
											<input type="text" class="form-input" id="description" placeholder="Description" data-skip-name="true" data-name="description" name="work_experience[0][company_description]" required>
										</div>
									</div>
								</div>
								</div>
								</div>								
								<div class="clearfix"></div>
							</div>
							<div class="repeater-heading">
								<button id="add-more" class="btn btn-primary pt-5 pull-right repeater-add-btn">
									Add More
								</button>
							</div>
							<div class="clearfix"></div>
						</div>
						
						<h2 class="form-title">Portfolios</h2>
						<div id="image_container"></div>
						<div class="dropzone"></div>
						<br>
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="Sign up"/>
                        </div>
                    <?php echo form_close() ?>
                   
                </div>
            </div>
        </section>

    </div>
	
	<script>
	
	$(document).ready(function () {
		var next = 0;
		$("#add-more").click(function(e){
			e.preventDefault();
			var addto = "#field" + next;
			var addRemove = "#field" + (next);
			next = next + 1;
			var newIn = ' <div id="field'+ next +'" name="field'+ next +'"><div class="item-content"><div class="form-group"><div class="col-lg-10"><input type="text" class="form-input" id="company_name" placeholder="Company Name" data-name="company_name" name="work_experience[' + next + '][company_name]"  required ></div></div><div class="form-group"><div class="col-lg-10"><input type="text" class="form-input" id="description" placeholder="Description" data-skip-name="true" data-name="description" name="work_experience[' + next + '][company_description]" required></div></div></div>';
			var newInput = $(newIn);
			var removeBtn = '<button id="remove' + (next - 1) + '" class="pull-right repeater-remove-btn btn btn-danger remove-me" >Remove</button></div></div><div id="field">';
			var removeButton = $(removeBtn);
			$(addto).after(newInput);
			$(addRemove).after(removeButton);
			$("#field" + next).attr('data-source',$(addto).attr('data-source'));
			$("#count").val(next);  
			
				$('.remove-me').click(function(e){
					e.preventDefault();
					var fieldNum = this.id.charAt(this.id.length-1);
					var fieldID = "#field" + fieldNum;
					$(this).remove();
					$(fieldID).remove();
				});
		});

	});
		
//Disabling autoDiscover
Dropzone.autoDiscover = false;

$(function() {
    //Dropzone class
    var myDropzone = new Dropzone(".dropzone", {
        url: "<?php echo SITE_URL; ?>/users/upload_portfolio_image",
        paramName: "file",
        maxFilesize: 2,
        maxFiles: 10,
        acceptedFiles: "image/*",
        autoProcessQueue: true,
		//addRemoveLinks: true,
		dictRemoveFileConfirmation: "Are you sure you want to remove this File?",    
		removedfile: function(file){
            /* var name = file.name;
            $.ajax({
                type: 'POST',
                url: '<?php echo SITE_URL; ?>/users/delete_portfolio_image',
                data: "name="+name,
                dataType: 'json',
				success: function (msg) {
				}
            }); */
            var _ref;
            return(_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
        },
		init: function() {
			this.on("success", function(file, response) {
				$("#image_container").append('<div><input type = "hidden" name="image_name[]" value="'+file.name+'"><div>');
			});
		}

    });
  
});

$('.datepicker').datepicker({
    format: 'yyyy-mm-dd',
	Default: true
});
</script>


