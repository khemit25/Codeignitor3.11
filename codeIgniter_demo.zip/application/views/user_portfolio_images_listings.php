<div class="container">
<div class="repeater-heading"><h2>Portfolios</h2>
	
</div>
<div class="clearfix"></div>
<div class="row">
	<a href="<?php echo site_url('users/users_listings') ?>" class="modal-trigger waves-effect btn-flat nopadding" style="color:#fff">Back</a>
	
	<div class="slide-box">
		<?php
		foreach($data as $result){
		?>
		<img src="<?php echo base_url().'uploads/'.$result->portfolio_image_name; ?>" width="285" height="200" >
		<?php
		}
		?>
	</div>
</div>
</div>
<style>
.slide-box img {
	margin: 2px;
}
</style>