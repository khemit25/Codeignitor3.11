
<div class="row">
  <div id="admin" class="col s12">
    <div class="card material-table">
      <div class="table-header">
        <span class="table-title">User Listing</span>
        <div class="actions">
          <a href="<?php echo site_url('/') ?>" class="modal-trigger waves-effect btn-flat nopadding"><i class="material-icons">person_add</i></a>
          <a href="#" class="search-toggle waves-effect btn-flat nopadding"><i class="material-icons">search</i></a>
        </div>
      </div>
      <table id="datatable">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Birth of Date</th>
            <th>Address</th>
            <th>Experiences</th>
            <th>Portfolios</th>
          </tr>
        </thead>
        <tbody>
			<?php
			foreach($data as $result){
			?>
          <tr>
            <td><?php echo $result->first_name; ?></td>           
            <td><?php echo $result->last_name; ?></td>           
            <td><?php echo $result->dob; ?></td> 
			<td><?php echo $result->address; ?></td>
			<td><a href="<?php echo site_url('users/user_experience_listings/'.$result->id) ?>">View</a></td>
			<td><a href="<?php echo site_url('users/user_portfolio_images_listings/'.$result->id) ?>">View</a></td>
          </tr>
		  <?php
		  }
		  ?>
        </tbody>
		
      </table>
    </div>
  </div>
</div>
</div>