<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model 
{
	/*Insert*/
	/*Insert*/
	function insert_entry($data){
		$this->db->insert('users',$data);
		return $this->db->insert_id(); 
	}
	
	
	public function users_listings()
	{
		$this->db->order_by('first_name', 'ASC');  
		$query=$this->db->get('users');
		return $query->result();
	}
	
	public function user_experience_listings($user_id)
	{
		$this->db->where('user_id',$user_id);
		$this->db->order_by('company_name', 'ASC');  
		$query=$this->db->get('users_work_experience');
		return $query->result();
	}
	
	public function user_portfolio_images_listings($user_id)
	{
		$this->db->where('user_id',$user_id);
		$this->db->order_by('id', 'ASC');  
		$query=$this->db->get('user_portfolio_images');
		return $query->result();
	}
}